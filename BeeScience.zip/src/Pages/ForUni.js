import React, { Component } from 'react';

class ForUni extends Component{
    render(){
        return(<h1>Test Foruni</h1>);
    }
}
export default ForUni;
    