import React, { Component } from 'react';

class GestorNotas extends Component{
    render(){
        return(<h1>Test Notas</h1>);
    }
}
export default GestorNotas;
    