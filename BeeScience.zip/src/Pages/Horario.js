import React, { Component } from 'react';

class Horario extends Component{
    render(){
        return(<h1>Test Horario</h1>);
    }
}
export default Horario;
    