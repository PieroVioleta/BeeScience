import React, { Component } from 'react';

class Recursos extends Component{
    render(){
        return(<h1>Test Recursos</h1>);
    }
}
export default Recursos;
    